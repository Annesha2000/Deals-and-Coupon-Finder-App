package com.capg.paymentgatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentGatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
